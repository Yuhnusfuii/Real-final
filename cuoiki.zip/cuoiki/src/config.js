// src/config.js
export const APP_NAME = import.meta.env.VITE_APP_NAME || "React Deploy App";
export const API_URL  = import.meta.env.VITE_API_URL  || "https://dummyjson.com";
